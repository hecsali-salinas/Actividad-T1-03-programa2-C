# python-lines-and-basic-polygons
python code to draw basic lines between two points and create basic polygons. Line program based on bresenham algorithm

<img src="https://github.com/sniperwlf/python-image-invert-colors/blob/master/images/Linea_solo_puntos.png" width="200">
<img src="https://github.com/sniperwlf/python-image-invert-colors/blob/master/images/Polygono.png" width="200">

